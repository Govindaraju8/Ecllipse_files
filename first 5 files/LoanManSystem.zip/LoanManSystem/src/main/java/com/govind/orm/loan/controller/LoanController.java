package com.govind.orm.loan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.govind.orm.loan.model.LoanApplicants;
import com.govind.orm.loan.model.LoanInputApplication;
import com.govind.orm.loan.model.User;
import com.govind.orm.loan.service.LoanService;

@Controller
public class LoanController {

	private LoanService loanser;
	private LoanInputApplication preobject;

	/*
	 * @Autowired private ExcelService excelService;
	 */

	@Autowired
	public LoanController(LoanService loanser) {
		this.loanser = loanser;
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String startingpage() {
		return "options";
	}

	@RequestMapping(value = "/loginbutton", method = RequestMethod.POST)
	public String mainpage() {
		return "login";
	}

	/*
	 * //login page
	 * 
	 * @RequestMapping(value = "/home", method = RequestMethod.GET) public String home() { return "login"; }
	 */

	@RequestMapping(value = "/registerbutton", method = RequestMethod.POST)
	public String register() {
		return "register";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registersucess(@ModelAttribute("User") User us1, Model model) {
		loanser.RegisterData(us1);
		System.out.println(us1);

		return "login";
	}

	@RequestMapping(value = "/userlogin", method = RequestMethod.POST)
	public String logindata(@ModelAttribute("User") User us, Model model) {
		if (loanser.checkCredentials(us)) {
			return "demo";
		} else {
			return "login";
		}
	}

	@RequestMapping(value = "/submitLoanApplication", method = RequestMethod.GET)
	public String LoanInput(@ModelAttribute("loanInputApplication") LoanInputApplication lnInput, Model model) {
		preobject = lnInput;
		model.addAttribute("loanlist", lnInput);

		return "preview";
	}

	@RequestMapping(value = "/submitForm", method = RequestMethod.POST)
	public String submitForm(Model model) {
		System.out.println(preobject);
		model.addAttribute("loanlist", preobject);
		return "demo";
	}

	@RequestMapping(value = "/saveform", method = RequestMethod.POST)
	public String SaveForm(Model model) {
		System.out.println(preobject);
		loanser.DataInsertion(preobject);
		model.addAttribute("serviceloan", preobject);
		return "approval";
	}

	@RequestMapping(value = "/LoanApplicants", method = RequestMethod.GET)
	public String LoanInput(Model model) {
		List<LoanApplicants> la = loanser.listAll();
		model.addAttribute("loanapps", la);
		return "loanappdata";
	}

	@RequestMapping(value = "/viewLoanApplicant", method = RequestMethod.GET)
	public String viewLoanApplicant(@RequestParam("lnapid") int lnapid, Model model) {
		LoanApplicants loanApplicant = loanser.getLoanApplicantById(lnapid);
		model.addAttribute("loanapp", loanApplicant);
		return "viewloanapp";
	}

	/*
	 * @RequestMapping(value = "/downloadExcel", method = RequestMethod.GET) public void
	 * downloadExcel(HttpServletResponse response) { try { // Fetch Loan Applicants data List<LoanApplicants> loanApps =
	 * loanser.listAll();
	 * 
	 * // Generate the Excel workbook using the service Workbook workbook =
	 * excelService.generateLoanApplicantsExcel(loanApps);
	 * 
	 * // Set response headers
	 * response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	 * response.setHeader("Content-Disposition", "attachment; filename=loan_applicants.xlsx");
	 * 
	 * // Write the Excel workbook to the response workbook.write(response.getOutputStream()); workbook.close();
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } }
	 */

	@RequestMapping(value = "/check", method = RequestMethod.GET)
	public String Checking(Model model) {
		// System.out.println(preobject);
		// model.addAttribute("loanlist",preobject);
		return "Checkeligible";
	}

}
