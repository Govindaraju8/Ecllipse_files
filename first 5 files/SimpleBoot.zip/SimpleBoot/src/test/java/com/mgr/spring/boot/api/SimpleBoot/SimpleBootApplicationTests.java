package com.mgr.spring.boot.api.SimpleBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
