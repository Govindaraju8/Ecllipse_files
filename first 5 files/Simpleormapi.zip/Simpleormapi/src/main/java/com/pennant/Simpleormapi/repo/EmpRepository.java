package com.pennant.Simpleormapi.repo;

public class EmpRepository {

}
