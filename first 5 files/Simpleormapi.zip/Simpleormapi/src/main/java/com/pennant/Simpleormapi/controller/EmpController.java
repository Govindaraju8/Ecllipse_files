package com.pennant.Simpleormapi.controller;

public class EmpController {

}
