package com.pennant.Simpleormapi.dao;

public class EmpDAO {

}
