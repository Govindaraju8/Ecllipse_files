package com.pennant.Simpleormapi.model;

public class Employee {

}
