package skm;

public class Employee789 {
	private int empNo;
	private String empName;
	private String job;
	private double salary;
	private String department;

	public Employee789() {
		// Default constructor
	}

	public Employee789(int empNo, String empName, String job, double salary, String department) {
		this.empNo = empNo;
		this.empName = empName;
		this.job = job;
		this.salary = salary;
		this.department = department;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

}
