package govind;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

class Employee789 {
	private int empNo;
	private String empName;
	private String job;
	private double salary;
	private String department;

	public Employee789() {
		// Default constructor
	}

	public Employee789(int empNo, String empName, String job, double salary, String department) {
		this.empNo = empNo;
		this.empName = empName;
		this.job = job;
		this.salary = salary;
		this.department = department;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	Connection conn = null;
	PreparedStatement pt = null;
	ResultSet rst = null;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String buttonClicked = request.getParameter("button");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		try {
			String url = "jdbc:postgresql://192.168.110.48:5432/plf_training";
			String username = "plf_training_admin";
			String password = "pff123";
			Class.forName("org.postgresql.Driver");

			Connection cn = DriverManager.getConnection(url, username, password);

			String selectQuery = "SELECT * FROM Employee789";
			Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rst = statement.executeQuery(selectQuery);

			ArrayList<Employee789> employeeList = new ArrayList<Employee789>();

			while (rst.next()) {
				int empNo = rst.getInt("empno");
				String empName = rst.getString("empname");
				String job = rst.getString("job");
				double salary = rst.getDouble("salary");
				String department = rst.getString("department");

				Employee789 employee = new Employee789();
				employee.setEmpNo(empNo);
				employee.setEmpName(empName);
				employee.setJob(job);
				employee.setSalary(salary);
				employee.setDepartment(department);

				employeeList.add(employee);
			}

			HttpSession session = request.getSession();

			Integer rowindex = (Integer) session.getAttribute("rowindex");
			String but = (String) session.getAttribute("but");

			if (rowindex == null) {
				rowindex = 0;
			}
			if (but == null) {
				but = "";
			}
			if (buttonClicked.equals("First")) {
				if (!employeeList.isEmpty()) {
					Employee789 firstEmployee = employeeList.get(0);
					JSONObject jsonResponse = new JSONObject();
					jsonResponse.put("empno", firstEmployee.getEmpNo());
					jsonResponse.put("empname", firstEmployee.getEmpName());
					jsonResponse.put("job", firstEmployee.getJob());
					jsonResponse.put("salary", firstEmployee.getSalary());
					jsonResponse.put("department", firstEmployee.getDepartment());

					response.setContentType("application/json");
					response.setCharacterEncoding("UTF-8");
					response.getWriter().write(jsonResponse.toString());
					session.setAttribute("rowindex", 0);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
