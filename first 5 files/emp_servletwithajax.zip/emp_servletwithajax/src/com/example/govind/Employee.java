package com.example.govind;

public class Employee {
	private String empNo;
	private String empName;
	private String job;
	private String salary;
	private String department;

	public Employee() {
		// Default constructor
	}

	public Employee(String empNo, String empName, String job, String salary, String department) {
		this.empNo = empNo;
		this.empName = empName;
		this.job = job;
		this.salary = salary;
		this.department = department;
	}

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}
