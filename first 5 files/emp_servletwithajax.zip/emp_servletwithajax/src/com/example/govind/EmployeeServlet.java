package com.example.govind;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String url = "jdbc:postgresql://192.168.110.48:5432/plf_training";
	private static final String username = "plf_training_admin";
	private static final String password = "pff123";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String empNo = request.getParameter("empNo");
		String empName = request.getParameter("empName");
		String job = request.getParameter("job");
		String salary = request.getParameter("salary");
		String department = request.getParameter("department");

		// Create an Employee object and store it in the session attribute
		Employee employee = new Employee(empNo, empName, job, salary, department);
		session.setAttribute("employee", employee);

		// You can also save the employee data to the database here
		// Save the employee data to the database
		if (saveEmployeeToDatabase(employee)) {
			response.getWriter().write("Employee data added and saved to the database successfully.");
		} else {
			response.getWriter().write("Failed to add employee data or save to the database.");
		}
	}

	private boolean saveEmployeeToDatabase(Employee employee) {
		// Database connection details

		try {
			Connection conn = DriverManager.getConnection(url, username, password);

			// Prepare SQL statement
			String insertQuery = "INSERT INTO Employee14 (empNo, empName, job, salary, department) VALUES (?,?, ?, ?, ?)";
			PreparedStatement pt = conn.prepareStatement(insertQuery);
			pt.setString(1, employee.getEmpNo());
			pt.setString(2, employee.getEmpName());
			pt.setString(3, employee.getJob());
			pt.setString(4, employee.getSalary());
			pt.setString(5, employee.getDepartment());

			// Execute the insert statement
			int rowsInserted = pt.executeUpdate();
			pt.close();
			conn.close();

			return rowsInserted > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}

}
