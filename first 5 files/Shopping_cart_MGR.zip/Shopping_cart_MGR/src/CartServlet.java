
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "cartServlet", urlPatterns = { "/cartServlet" })
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CartServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");

		// Retrieve the cart items parameter from the URL
		String cartItemsParam = request.getParameter("cartItems");

		// You would typically perform further processing on the cart items parameter,
		// such as converting it back from JSON and displaying the cart items.

		// For this example, let's assume you directly send back the received parameter.
		PrintWriter out = response.getWriter();
		out.print(cartItemsParam);

		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter pp = response.getWriter();
		pp.println("<html>");
		pp.println("<head>");
		pp.println("<title> this is demo servlet mapping </title>");
		pp.println("</head>");
		pp.println("<body>");
		pp.println("<h1> this is  a basic servlet program </h1>");
		pp.println("</body>");
		pp.println("</html>");
	}

}
